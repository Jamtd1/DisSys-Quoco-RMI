package service.message;

import java.util.List;

import java.io.Serializable;
import service.core.*;

public class QuotationResponsesMessage implements Serializable {
    public long id;
    public ClientInfo info;
    public List<Quotation> quotations;

    public QuotationResponsesMessage(long id, ClientInfo info, List<Quotation> quotations) {
        this.id = id;
        this.info = info;
        this.quotations = quotations;
    }
}